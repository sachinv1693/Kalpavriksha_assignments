﻿using System;
using System.Collections.Generic;
using System.Text;

namespace mySample
{
    class Sample
    {
        public void show(out int num)
        {
            int a = 9;
            num = a + 1;
            num += 1;
            Console.WriteLine($"Hello, this is Sample {num}");
        }

    }

    
}
