﻿using mySample;
using System;

namespace myCSharpApp
{
    class Program
    {
        static int number = 10;
        static Sample sample = new Sample();
        static void Main(string[] args)
        {
            sample.show(out number);
            Console.WriteLine($"Hello, this is in Program {number}");

            //const int LIST_SIZE = 50;
            //string[] list_of_devices = new string[LIST_SIZE];
            //Array.Fill(list_of_devices, "");
            //double[] price_list = new double[LIST_SIZE];
            //Array.Fill(price_list, 0.0);
            //char option;
            //int total_no_of_devices = 0;
            //do
            //{
            //    display_menu();
            //    int menu_option;
            //    if (!int.TryParse(Console.ReadLine(), out menu_option))
            //    {
            //        Console.WriteLine("Invalid input! Please enter a valid integer choice.");
            //    }
            //    switch (menu_option)
            //    {
            //        case 1://Display list of all devices
            //            if (total_no_of_devices > 0)
            //                display_devices(list_of_devices, price_list);
            //            else
            //                Console.WriteLine("There are no devices in the list. Please add devices into the list!");
            //            break;
            //        case 2://Add devices into the list
            //            Console.Write("How many devices would you like to add in the list?: ");
            //            int no_of_devices;
            //            if (!int.TryParse(Console.ReadLine(), out no_of_devices))
            //            {
            //                Console.WriteLine("Invalid input! Please enter a valid integer choice.");
            //                break;
            //            }
            //            if (total_no_of_devices + no_of_devices < LIST_SIZE)
            //            {
            //                //add_devices_into_list(list_of_devices, price_list, no_of_devices, total_no_of_devices);
            //                for (int index = total_no_of_devices; index < total_no_of_devices + no_of_devices; index++)
            //                {
            //                    Console.Write($"Please enter the name of the device {index + 1}: ");
            //                    string dev_name = Console.ReadLine();
            //                    list_of_devices[index] = dev_name;
            //                    Console.Write($"Please enter the price of the device {index + 1}: ");
            //                    double price = Convert.ToDouble(Console.ReadLine());
            //                    price_list[index] = price;
            //                }
            //                total_no_of_devices += no_of_devices;
            //            }
            //            else
            //                Console.WriteLine($"Sorry, we cannot add {no_of_devices} devices in the list!");
            //            break;
            //        case 3://Search for a device
            //            Console.Write("Please enter the name of device you want to search: ");
            //            string device_name = Console.ReadLine();
            //            search_for_a_device(list_of_devices, price_list, device_name);
            //            break;
            //        case 4://Exit
            //            return;
            //        default://Invalid menu option
            //            Console.WriteLine("Invalid menu option!!");
            //            break;
            //    }
            //    Console.Write("Press 'y' or 'Y' to continue or press any other key to exit: ");
            //    if (!char.TryParse(Console.ReadLine(), out option))
            //    {
            //        Console.WriteLine("Invalid input!");
            //    }
            //}
            //while (option == 'Y' | option == 'y');
        }

        static void display_menu()
        {
            Console.WriteLine("---------------Menu-----------------");
            Console.WriteLine("1. Display list of all devices");
            Console.WriteLine("2. Add devices into the list");
            Console.WriteLine("3. Search for a device");
            Console.WriteLine("4. Exit");
            Console.Write("Please select an option: ");
        }

        /*
        static void add_devices_into_list(string[] list_of_devices, double[] price_list, int no_of_devices, int total_no_of_devices)
        {
           
        }
        */

        static void display_devices(string[] list_of_devices, double[] price_list)
        {
            Console.WriteLine("Following is the list of devices:");
            Console.WriteLine("Sr. No.\tDevice Name\t\t\t\t\tPrice");
            Console.WriteLine("-------------------------------------------------------------");
            for (int index = 0; index < list_of_devices.Length; index++)
            {
                if (price_list[index] == 0.0)
                    break;
                Console.Write(Convert.ToString(index + 1) + "\t" + list_of_devices[index] + "\t\t\t\t\t");
                Console.WriteLine(price_list[index]);
            }
            Console.WriteLine("------------------------------------------------------------");
        }

        static void search_for_a_device(string[] list_of_devices, double[] price_list, string device_name)
        {
            for (int index = 0; index < list_of_devices.Length; index++)
            {
                if (device_name == list_of_devices[index])
                {
                    Console.WriteLine("This device is found in the list!");
                    Console.WriteLine($"Debice Price: {price_list[index]}");
                    return;
                }
                index++;
            }
            Console.WriteLine("This device does not exist in the list!");
        }
    }
}
